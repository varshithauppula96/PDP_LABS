package transmission;

/**
 * Enumeration class to store gear values.
 */
public enum Gear {
  zero, one, two, three, four, five, six
}
